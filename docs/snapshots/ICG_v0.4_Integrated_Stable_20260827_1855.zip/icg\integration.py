"""
ICG <-> UniPlag integration layer (app/icg/integration.py)
=============================================================
Aris Directive (ICG live integration, v0.4):
  - Strict Fast/Slow path separation.
  - check_icg_fast(): main pipeline (fast deterministic contour, default).
  - check_icg_deep(): slow path (31b judges + Fact-Judge); for background/deep analysis only.
  - ICGHealth black-box is written by icg_watchdog.py.
"""
from typing import Dict, Any, Optional, Tuple
import json

from .graph_builder import ICGGraphBuilder


def _build_graph_fast(document_id: str, text: str) -> Any:
    builder = ICGGraphBuilder()
    return builder.build_graph(document_id=document_id, text=text, use_llm=False)


def _build_graph_deep(document_id: str, text: str) -> Any:
    builder = ICGGraphBuilder()
    return builder.build_graph(document_id=document_id, text=text, use_llm=True)


def _summarize(graph: Any) -> Dict[str, Any]:
    m = graph.metrics_summary
    return {
        "intellectual_contribution_score": round(float(m.intellectual_contribution_score), 4),
        "reproduction_ratio": round(float(m.reproduction_ratio), 4),
        "synthesis_ratio": round(float(m.synthesis_ratio), 4),
        "source_novel_synthesis_ratio": round(float(m.source_novel_synthesis_ratio), 4),
        "higher_order_synthesis_ratio": round(float(m.higher_order_synthesis_ratio), 4),
        "original_contribution_ratio": round(float(m.original_contribution_ratio), 4),
        "inference_ratio": round(float(m.inference_ratio), 4),
        "unsupported_ratio": round(float(m.unsupported_ratio), 4),
        "contradictory_ratio": round(float(m.contradictory_ratio), 4),
        "novelty_score": round(float(m.novelty_score), 4),
        "synthesis_depth": round(float(m.synthesis_depth), 4),
        "inference_depth": round(float(m.inference_depth), 4),
        "evidence_coverage": round(float(m.evidence_coverage), 4),
        "reasoning_coherence": round(float(m.reasoning_coherence), 4),
        "external_corpus_coverage": round(float(m.external_corpus_coverage), 4),
        "global_epistemic_confidence": round(float(m.global_epistemic_confidence), 4),
        "node_count": len(graph.nodes),
        "edge_count": len(graph.edges),
    }


def check_icg_fast(document_id: str, text: str) -> Tuple[float, Dict[str, Any], str]:
    """Fast contour: returns (icg_score_0_100, summary_dict, json_payload)."""
    graph = _build_graph_fast(document_id, text)
    score = round(float(graph.metrics_summary.intellectual_contribution_score) * 100.0, 1)
    summary = _summarize(graph)
    payload = {
        "contour": "fast",
        "score": score,
        "summary": summary,
        "ratios": {
            "synthesis": summary["synthesis_ratio"] + summary["source_novel_synthesis_ratio"]
                       + summary["higher_order_synthesis_ratio"],
            "inference": summary["inference_ratio"],
            "unsupported": summary["unsupported_ratio"],
            "contradictory": summary["contradictory_ratio"],
            "reproduction": summary["reproduction_ratio"],
        },
    }
    # Aris Directive: keep the user-facing ICG section (report.html) working —
    # embed the full graph dump so `metrics_summary` / `nodes` remain available.
    try:
        dump = graph.model_dump()
        if isinstance(dump, dict):
            payload["metrics_summary"] = dump.get("metrics_summary", {})
            payload["nodes"] = dump.get("nodes", [])
    except Exception:
        pass
    return score, summary, json.dumps(payload, ensure_ascii=False)


def check_icg_deep(document_id: str, text: str) -> Tuple[float, Dict[str, Any], str]:
    """Slow path (31b judges + Fact-Judge). For background/deep analysis; NOT for HTTP request."""
    graph = _build_graph_deep(document_id, text)
    score = round(float(graph.metrics_summary.intellectual_contribution_score) * 100.0, 1)
    summary = _summarize(graph)
    payload = {
        "contour": "deep",
        "score": score,
        "summary": summary,
        "ratios": {
            "synthesis": summary["synthesis_ratio"] + summary["source_novel_synthesis_ratio"]
                       + summary["higher_order_synthesis_ratio"],
            "inference": summary["inference_ratio"],
            "unsupported": summary["unsupported_ratio"],
            "contradictory": summary["contradictory_ratio"],
            "reproduction": summary["reproduction_ratio"],
        },
    }
    try:
        dump = graph.model_dump()
        if isinstance(dump, dict):
            payload["metrics_summary"] = dump.get("metrics_summary", {})
            payload["nodes"] = dump.get("nodes", [])
    except Exception:
        pass
    return score, summary, json.dumps(payload, ensure_ascii=False)
