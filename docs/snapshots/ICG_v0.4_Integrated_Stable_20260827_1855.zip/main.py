import json
import secrets
import threading
from contextlib import asynccontextmanager
from pathlib import Path

from fastapi import Depends, FastAPI, HTTPException, Request, UploadFile, File, Form
from fastapi.responses import HTMLResponse, RedirectResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from sqlalchemy import func
from sqlalchemy.orm import Session

from . import config
from .auth import current_user, create_session, get_db
from .checker import run_check
from .crawler import fetch_url
from .db import Check, Document, SessionLocal, User, init_db
from .fingerprint import fingerprint
from .parsing import extract_text
from .plagiarism import corpus_index, ensure_index

BASE = Path(__file__).resolve().parent
templates = Jinja2Templates(directory=str(BASE / "templates"))


@asynccontextmanager
async def lifespan(_app: FastAPI):
    init_db()
    config.UPLOAD_DIR.mkdir(parents=True, exist_ok=True)
    with SessionLocal() as db:
        if not db.query(User).count():
            admin = User(username="admin", role="admin")
            admin.set_password("admin123")
            db.add(admin)
            db.commit()
            print("Создан администратор по умолчанию: admin / admin123 (смените пароль!)")
    yield


app = FastAPI(title="UniPlag", lifespan=lifespan)


@app.get("/login", response_class=HTMLResponse)
def login_page(request: Request):
    return templates.TemplateResponse(request, "login.html", {"error": ""})


@app.post("/login")
def login(
    request: Request,
    username: str = Form(...),
    password: str = Form(...),
    db: Session = Depends(get_db),
):
    user = db.query(User).filter(User.username == username).first()
    if not user or not user.check_password(password):
        return templates.TemplateResponse(
            request, "login.html", {"error": "Неверный логин или пароль"}, status_code=401
        )
    resp = RedirectResponse("/", status_code=303)
    resp.set_cookie("uniplag_session", create_session(user.id), httponly=True)
    return resp


@app.get("/logout")
def logout():
    resp = RedirectResponse("/login", status_code=303)
    resp.delete_cookie("uniplag_session")
    return resp


@app.get("/", response_class=HTMLResponse)
def dashboard(request: Request, db: Session = Depends(get_db), user: User = Depends(current_user)):
    checks = db.query(Check).order_by(Check.created_at.desc()).limit(50).all()
    stats = {
        "docs": db.query(func.count(Document.id)).scalar() or 0,
        "checks": db.query(func.count(Check.id)).scalar() or 0,
        "web": db.query(func.count(Document.id)).filter(Document.kind == "web").scalar() or 0,
    }
    return templates.TemplateResponse(
        request, "dashboard.html", {"user": user, "checks": checks, "stats": stats}
    )


@app.get("/upload", response_class=HTMLResponse)
def upload_page(request: Request, user: User = Depends(current_user)):
    return templates.TemplateResponse(request, "upload.html", {"user": user, "results": None, "errors": []})


@app.post("/upload")
async def upload(
    request: Request,
    files: list[UploadFile] = File(...),
    author: str = Form(""),
    mode: str = Form("both"),
    do_quality: bool = Form(False),
    db: Session = Depends(get_db),
    user: User = Depends(current_user),
):
    results, errors = [], []
    for f in files:
        raw = await f.read()
        if len(raw) > config.MAX_UPLOAD_BYTES:
            errors.append(f"{f.filename}: файл больше 20 МБ")
            continue
        config.UPLOAD_DIR.mkdir(parents=True, exist_ok=True)
        safe_name = f"{secrets.token_hex(8)}_{Path(f.filename).name}"
        path = config.UPLOAD_DIR / safe_name
        path.write_bytes(raw)
        try:
            text = extract_text(path)
        except Exception as e:
            errors.append(f"{f.filename}: {e}")
            continue
        doc = Document(
            title=Path(f.filename).stem[:300],
            author=author,
            kind="student",
            filename=f.filename,
            text=text,
            words=len(text.split()),
        )
        db.add(doc)
        db.commit()
        db.refresh(doc)
        corpus_index.add(doc.id, fingerprint(text))
        do_plag = mode in ("plag", "both")
        do_ai = mode in ("ai", "both")
        check = run_check(db, doc, do_plag=do_plag, do_ai=do_ai, do_quality=do_quality)
        results.append(check)
    return templates.TemplateResponse(
        request, "upload.html", {"user": user, "results": results, "errors": errors}
    )


@app.get("/report/{check_id}", response_class=HTMLResponse)
def report_page(check_id: int, request: Request, db: Session = Depends(get_db), user: User = Depends(current_user)):
    check = db.get(Check, check_id)
    if not check:
        raise HTTPException(404)
    ai_data = json.loads(check.ai_json) if check.ai_json else {}
    quality_data = json.loads(check.quality_json) if check.quality_json else {}
    icg_data = json.loads(check.icg_json) if getattr(check, "icg_json", None) else {}
    highlighted = build_highlighted_html(db, check)
    doc_ids = {m.source_doc_id for m in check.matches}
    docs_map = {d.id: d for d in db.query(Document).filter(Document.id.in_(doc_ids))} if doc_ids else {}
    has_highlights = bool(check.matches) or any(
        s.get("ai", 0) >= config.AI_THRESHOLD_WARN for s in ai_data.get("sentences", [])
    )
    return templates.TemplateResponse(
        request, "report.html",
        {"user": user, "check": check, "doc": check.document, "ai": ai_data,
         "quality": quality_data, "icg": icg_data, "highlighted": highlighted, "docs_map": docs_map,
         "has_highlights": has_highlights},
    )


@app.post("/corpus/add-url")
def corpus_add_url(
    request: Request,
    url: str = Form(...),
    db: Session = Depends(get_db),
    user: User = Depends(current_user),
):
    try:
        page = fetch_url(url.strip())
    except Exception as e:
        return templates.TemplateResponse(
            request, "corpus.html",
            {"user": user, "docs": list_documents(db), "msg": f"Ошибка: {e}"},
            status_code=400,
        )
    doc = Document(
        title=page["title"], kind="web", url=page["url"], domain=page["domain"],
        text=page["text"], words=len(page["text"].split()),
    )
    db.add(doc)
    db.commit()
    db.refresh(doc)
    corpus_index.add(doc.id, fingerprint(page["text"]))
    return RedirectResponse("/corpus", status_code=303)


@app.get("/corpus", response_class=HTMLResponse)
def corpus_page(request: Request, db: Session = Depends(get_db), user: User = Depends(current_user)):
    return templates.TemplateResponse(
        request, "corpus.html", {"user": user, "docs": list_documents(db), "msg": ""}
    )


@app.delete("/api/documents/{doc_id}")
def delete_document(doc_id: int, db: Session = Depends(get_db), user: User = Depends(current_user)):
    doc = db.get(Document, doc_id)
    if doc:
        corpus_index.remove(doc_id)
        db.delete(doc)
        db.commit()
    return {"ok": True}


def list_documents(db: Session, limit: int = 200):
    return db.query(Document).order_by(Document.uploaded_at.desc()).limit(limit).all()


def build_highlighted_html(db: Session, check: Check) -> str:
    import html as html_mod

    from .plagiarism import merge_spans

    text = check.document.text
    spans = [(fr.q_start, fr.q_end) for m in check.matches for fr in m.fragments]
    ai = json.loads(check.ai_json) if check.ai_json else {}
    ai_spans = [
        (s["start"], s["end"]) for s in ai.get("sentences", []) if s.get("ai", 0) >= config.AI_THRESHOLD_WARN
    ]
    plag_set = set(merge_spans(spans))
    ai_set = set(merge_spans(ai_spans))
    all_spans = sorted(plag_set | ai_set)

    parts, pos = [], 0
    for s, e in all_spans:
        if s < pos:
            continue
        parts.append(html_mod.escape(text[pos:s]))
        is_plag = any(ps <= s and e <= pe for ps, pe in plag_set)
        css = "frag-plag" if is_plag else "frag-ai"
        title = "Заимствование" if is_plag else "Возможный ИИ-текст"
        parts.append(f'<span class="{css}" title="{title}">{html_mod.escape(text[s:e])}</span>')
        pos = e
    parts.append(html_mod.escape(text[pos:]))
    return "".join(parts)


app.mount("/static", StaticFiles(directory=str(BASE / "static")), name="static")

from .api import router as api_router  # noqa: E402

app.include_router(api_router)


# ---------------------------------------------------------------------------
# Aris Directive: ICG Admin Control Interface (/admin/icg)
# ---------------------------------------------------------------------------
def _require_admin(user):
    if not user or getattr(user, "role", "teacher") != "admin":
        raise HTTPException(403, "Только администратор")


_icg_deep_lock = threading.Lock()
_icg_deep_running = False


@app.get("/admin/icg", response_class=HTMLResponse)
def icg_admin_page(request: Request, db: Session = Depends(get_db), user: User = Depends(current_user)):
    _require_admin(user)

    from .icg.icg_watchdog import last_health, DEGRADED_LEVELS
    from .db import ICGHealth

    health = last_health(db)
    health_hist = db.query(ICGHealth).order_by(ICGHealth.id.desc()).limit(20).all()

    # Recent checks with ICG payload
    checks = db.query(Check).order_by(Check.id.desc()).limit(100).all()
    rows = []
    for c in checks:
        icg = {}
        try:
            icg = json.loads(c.icg_json) if c.icg_json else {}
        except Exception:
            icg = {}
        ratios = icg.get("ratios", {})
        summary = icg.get("summary", {})
        rows.append({
            "id": c.id,
            "created": c.created_at.strftime("%d.%m %H:%M") if c.created_at else "",
            "doc_id": c.document_id,
            "icg_score": c.icg_score,
            "degraded": bool(icg.get("degraded")),
            "synthesis": round(ratios.get("synthesis", 0) * 100, 1),
            "inference": round(ratios.get("inference", 0) * 100, 1),
            "unsupported": round(ratios.get("unsupported", 0) * 100, 1),
            "contradictory": round(ratios.get("contradictory", 0) * 100, 1),
            "novelty": round(summary.get("novelty_score", 0) * 100, 1),
            "coherence": round(summary.get("reasoning_coherence", 0) * 100, 1),
            "evidence": round(summary.get("evidence_coverage", 0) * 100, 1),
        })

    d = {
        "health": None if health is None else {
            "id": health.id,
            "ts": health.ts.strftime("%d.%m %H:%M") if health.ts else "",
            "blind": f"{health.blind_score}/{health.blind_tot}",
            "red": f"{health.red_score}/{health.red_tot}",
            "level": DEGRADED_LEVELS.get(int(health.degraded), "ok"),
            "degraded": bool(health.degraded),
            "details": json.loads(health.details_json) if health.details_json else {},
        },
        "health_hist": [{
            "id": h.id,
            "ts": h.ts.strftime("%d.%m %H:%M") if h.ts else "",
            "blind": f"{h.blind_score}/{h.blind_tot}",
            "red": f"{h.red_score}/{h.red_tot}",
            "level": DEGRADED_LEVELS.get(int(h.degraded), "ok"),
        } for h in health_hist],
        "rows": rows,
        "baselines": {"blind": "19/22", "red": "17/30"},
    }
    return templates.TemplateResponse(request, "icg_admin.html", {"user": user, "d": d})


@app.post("/admin/icg/watchdog", response_class=HTMLResponse)
def icg_admin_trigger_watchdog(request: Request, db: Session = Depends(get_db), user: User = Depends(current_user)):
    _require_admin(user)
    from .icg.icg_watchdog import run_watchdog_once
    res = run_watchdog_once(db)
    return RedirectResponse("/admin/icg", status_code=303)


@app.post("/admin/icg/deep/{check_id}", response_class=HTMLResponse)
def icg_admin_deep_recheck(check_id: int, request: Request, db: Session = Depends(get_db),
                           user: User = Depends(current_user)):
    _require_admin(user)
    global _icg_deep_running
    check = db.get(Check, check_id)
    if not check:
        raise HTTPException(404)
    if _icg_deep_lock.acquire(blocking=False):
        try:
            if _icg_deep_running:
                return RedirectResponse("/admin/icg", status_code=303)
            _icg_deep_running = True
        finally:
            _icg_deep_lock.release()
    else:
        return RedirectResponse("/admin/icg", status_code=303)

    def _run():
        global _icg_deep_running
        try:
            from .icg.integration import check_icg_deep
            from .db import SessionLocal
            with SessionLocal() as db2:
                c2 = db2.get(Check, check_id)
                doc = c2.document
                _, _, payload = check_icg_deep(str(doc.id), doc.text)
                obj = json.loads(c2.icg_json or "{}")
                deep = json.loads(payload)
                deep["contour"] = "deep"
                obj["deep"] = deep
                c2.icg_json = json.dumps(obj, ensure_ascii=False)
                db2.commit()
        except Exception:
            pass
        finally:
            _icg_deep_running = False

    threading.Thread(target=_run, daemon=True).start()
    return RedirectResponse("/admin/icg", status_code=303)
