import json
import threading

from .ai_detector import detect as ai_detect
from .db import Check, Document, Fragment, Match
from .fingerprint import fingerprint
from .plagiarism import align_fragments, corpus_index, ensure_index
from .quality import assess as quality_assess

# Aris Directive (ICG integration): background watchdog trigger, one daemon thread at a time.
_watchdog_lock = threading.Lock()
_watchdog_running = False


def _schedule_watchdog(db):
    """Run watchdog off the HTTP thread when due (6h OR 500 checks). Non-blocking."""
    global _watchdog_running
    if not _watchdog_lock.acquire(blocking=False):
        return
    try:
        if _watchdog_running:
            return
        from .icg.icg_watchdog import should_run_watchdog, last_health
        h = last_health(db)
        checks_since = 0
        if h is not None and h.ts is not None:
            from sqlalchemy import func
            checks_since = db.query(func.count(Check.id)).filter(Check.created_at > h.ts).scalar() or 0
        if not should_run_watchdog(db, checks_since):
            return
        _watchdog_running = True
    finally:
        _watchdog_lock.release()

    def _run():
        global _watchdog_running
        try:
            from .icg.icg_watchdog import run_watchdog_once
            from .db import SessionLocal
            with SessionLocal() as db2:
                run_watchdog_once(db2)
        except Exception:
            pass
        finally:
            _watchdog_running = False

    threading.Thread(target=_run, daemon=True).start()


def run_check(db, doc: Document, do_plag: bool = True, do_ai: bool = True,
              do_quality: bool = False) -> Check:
    ensure_index(db)
    fp = fingerprint(doc.text)

    check = Check(document_id=doc.id)
    db.add(check)

    if do_plag:
        cands = corpus_index.candidates(fp, exclude=doc.id)
        total_matched_chars = 0
        for cand_id, est_sim in cands:
            cand = db.get(Document, cand_id)
            percent, spans = align_fragments(doc.text, cand.text)
            if percent < 0.5 or not spans:
                continue
            m = Match(
                check=check,
                source_doc_id=cand.id,
                source_label=cand.title,
                sim=percent,
                matched_words=int(round(len(fp["hashes"]) * percent / 100)) + config_shingle_k(),
            )
            for s, e in spans:
                total_matched_chars += e - s
                m.fragments.append(Fragment(q_start=s, q_end=e, text=doc.text[s:e][:500]))
            db.add(m)
        chars = max(len(doc.text), 1)
        from .plagiarism import merge_spans
        all_spans = [(fr.q_start, fr.q_end) for match in check.matches for fr in match.fragments]
        union = sum(e - s for s, e in merge_spans(all_spans))
        check.plag_score = round(min(100.0 * union / chars, 99.9), 2)

    if do_ai:
        result = ai_detect(doc.text)
        check.ai_score = max(result.get("score", 0.0), 0.0)
        check.ai_method = result.get("method", "")
        check.ai_json = json.dumps(result, ensure_ascii=False)

    if do_quality:
        qr = quality_assess(doc.text)
        check.quality_json = json.dumps(qr, ensure_ascii=False)

    # Intellectual Contribution Graph (ICG) Analysis — Aris Directive: via integration layer (FAST contour).
    try:
        from .icg.integration import check_icg_fast
        from .icg.icg_watchdog import current_degraded
        icg_score, icg_summary, icg_payload = check_icg_fast(str(doc.id), doc.text)
        check.icg_score = icg_score
        if current_degraded(db):
            _obj = json.loads(icg_payload)
            _obj["degraded"] = True
            _obj["disclaimer"] = "Внимание: точность ICG временно снижена (регрессия v0.4)."
            icg_payload = json.dumps(_obj, ensure_ascii=False)
        check.icg_json = icg_payload
    except Exception as e:
        check.icg_score = 0.0
        check.icg_json = json.dumps({"error": str(e)}, ensure_ascii=False)

    # Aris Directive: background watchdog health trigger (6h OR 500 checks) — non-blocking.
    _schedule_watchdog(db)

    db.commit()
    db.refresh(check)
    return check


def config_shingle_k() -> int:
    from . import config
    return config.SHINGLE_K
